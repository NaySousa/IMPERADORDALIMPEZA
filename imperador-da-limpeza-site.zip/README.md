# Imperador da Limpeza — Site

Site estático pronto para publicar gratuitamente no **GitHub Pages**.

## Arquivos

- `index.html` — página principal
- `style.css` — visual e responsividade
- `script.js` — WhatsApp, menu e ano automático
- `logo.png` — logo fornecido

## Antes de publicar

Abra `script.js` e altere:

```js
const WHATSAPP_NUMBER = "5585999999999";
```

Coloque o número real do WhatsApp com código do país e DDD, somente números.

## Publicar no GitHub Pages

1. Crie uma conta no GitHub, se ainda não tiver.
2. Crie um novo repositório, por exemplo: `imperador-da-limpeza`.
3. Envie todos os arquivos desta pasta para o repositório.
4. No GitHub, entre em **Settings → Pages**.
5. Em **Build and deployment**, escolha **Deploy from a branch**.
6. Selecione a branch `main` e a pasta `/ (root)`.
7. Salve e aguarde a publicação.

O GitHub fornecerá um endereço parecido com:

`https://SEU-USUARIO.github.io/imperador-da-limpeza/`

## Personalizações

O conteúdo foi preparado com textos genéricos para que você possa trocar facilmente:
- cidade/região de atendimento;
- número do WhatsApp;
- horários;
- serviços;
- endereço;
- redes sociais;
- fotos dos serviços;
- depoimentos de clientes.

Não é necessário banco de dados ou servidor: o site funciona como uma página estática.
