// ===============================
// CONFIGURAÇÃO DO SITE
// ===============================
// Troque pelo número de WhatsApp da empresa, com DDI + DDD.
// Exemplo: 5585999999999
const WHATSAPP_NUMBER = "5585999999999";
const WHATSAPP_MESSAGE = "Olá! Vim pelo site da Imperador da Limpeza e gostaria de solicitar um orçamento.";

document.querySelectorAll(".whatsapp-link").forEach((link) => {
  link.href = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(WHATSAPP_MESSAGE)}`;
});

document.getElementById("year").textContent = new Date().getFullYear();

const menuToggle = document.querySelector(".menu-toggle");
const menu = document.getElementById("menu");

menuToggle?.addEventListener("click", () => {
  menu.classList.toggle("open");
});

document.querySelectorAll("#menu a").forEach((item) => {
  item.addEventListener("click", () => menu.classList.remove("open"));
});
